Created by Osvaldas Valutis: www.osvaldas.info
for Codrops